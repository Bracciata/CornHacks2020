package com.example.recyclops

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class GuideActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Begin with Pokemon Go esque disclaimer on recycling
        openGuide()

    }
    private fun openGuide(){
        
    }
    private fun returnToMain(){
        
    }
}