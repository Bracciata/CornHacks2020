["paper", "newspaper", "cardboard", "plastic", "phonebooks", "magazines", "mail", "tin", "aluminum",
    "steel", "glass", "soft drink", "beer bottles", "wine", "liquor"]